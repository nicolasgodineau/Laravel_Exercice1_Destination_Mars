<?php $__env->startSection('title', 'Merci'); ?>

<?php $__env->startSection('content'); ?>
<main
    class="bg-[url('assets/img/home.webp')] bg-no-repeat bg-auto bg-center w-[100%] h-[100%] flex flex-col items-center gap-[10%] rounded-[30px] pt-8 ">
    <?php $__env->startSection('nav'); ?>
    <section
        class="backdrop-blur-xl rounded-[30px] bg-[#0000003d] flex flex-col items-center justify-evenly w-[1000px]  pb-12">
        <h1 class="fs-6 font-ArchivoBlack text-small text-white text-center uppercase">
            merci !</h1>
        <div class="flex flex-row gap-9 items-center justify-center h-fit w-full p-8">
            <div class="flex flex-col gap-9 items-center justify-center h-fit w-full p-8 ">
                <?php if(isset($data)): ?>
                <p><strong>Nom: </strong><?php echo e($data->nom  ?? ''); ?></p>
                <p><strong>Prénom: </strong><?php echo e($data->prenom ?? ''); ?></p>
                <p><strong>Email: </strong><?php echo e($data->email ?? ''); ?></p>
                <?php else: ?>
                <?php endif; ?>
            </div>
        </div>

    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/Nicolas/Documents/Formation/200-PHP/230-Exercices/234-Session4/Exercice1/resources/views/liste.blade.php ENDPATH**/ ?>