# Exercice 1 - Laravel

### Création du projet:  
composer create-project --prefer-dist laravel/laravel Exercice1 "8.\*"

###Création du contrôleur:
php artisan make:controller MasterController